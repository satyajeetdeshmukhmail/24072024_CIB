﻿using MaterialSkin;
using MaterialSkin.Controls;
using System;
using System.Drawing;
using System.Windows.Forms;
using BLL;
using FHL;


namespace CIB
{
    public partial class CIB : MaterialForm
    {
        public CIB()
        {
            InitializeComponent();

            // Subscribe to mouse events for buttons to change the colors
            
            btnUpdateComPorts.MouseDown += btnUpdateComPorts_MouseDown;
            btnUpdateComPorts.MouseUp += btnUpdateComPorts_MouseUp;

            btnConnect.MouseDown += btnConnect_MouseDown;
            btnConnect.MouseUp += btnConnect_MouseUp;

            btnDisconnect.MouseDown += btnDisconnect_MouseDown;
            btnDisconnect.MouseUp += btnDisconnect_MouseUp;

            btnStartToSendData.MouseDown += btnStartToSendData_MouseDown;
            btnStartToSendData.MouseUp += btnStartToSendData_MouseUp;

            btnStopData.MouseDown += btnStopData_MouseDown;
            btnStopData.MouseUp += btnStopData_MouseUp;
           
            
            btnGenerateTestReport.MouseDown += btnGenerateTestReport_MouseDown;
            btnGenerateTestReport.MouseUp += btnGenerateTestReport_MouseUp;

            btnExitForm.MouseDown += btnExitForm_MouseDown;
            btnExitForm.MouseUp += btnExitForm_MouseUp;

            btnClearTextBoxData.MouseDown += btnClearTextBoxData_MouseDown;
            btnClearTextBoxData.MouseUp += btnClearTextBoxData_MouseUp;

            // Create a material theme manager and add the form to manage (this)
            MaterialSkinManager materialSkinManager = MaterialSkinManager.Instance;
            materialSkinManager.AddFormToManage(this);
            materialSkinManager.Theme = MaterialSkinManager.Themes.LIGHT;

            // Configure color schema
            materialSkinManager.ColorScheme = new ColorScheme(
                Primary.Blue400, Primary.Blue500,
                Primary.Yellow500, Accent.LightGreen100,
                TextShade.WHITE
            );
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timerDateDayTime.Enabled = true; manualFileCreation.CreateFile(); manualFileCreation.CreateFile();  
        }

        private void timerDateDayTime_Tick(object sender, EventArgs e)
        {
            // Get current date and time
            DateTime now = DateTime.Now;

            // Update labels with formatted strings
            lblTimeValue.Text = now.ToString("hh:mm:ss tt"); // Example format for time
            lblDay.Text = now.ToString("dddd"); // Example format for day
            lblDateValue.Text = now.ToString("MMMM dd, yyyy"); // Example format for date
        }


    PortsService portService = new PortsService();
        ClearData clrData= new ClearData(); 
        ManualFileCreation manualFileCreation = new ManualFileCreation();
        public void UpdateComPortsList()
        {
            // Clear existing items in the ComboBox
            cBoxCOMPORT.Items.Clear();

            try
            {
                // Get the updated list of serial ports
                string[] serialPorts = portService.GetAllSerialPorts();

                // Check if ports were retrieved
                if (serialPorts.Length > 0)
                {
                    // Add each serial port to the ComboBox
                    foreach (string port in serialPorts)
                    {
                        cBoxCOMPORT.Items.Add(port);
                    }

                    // Show a message box to indicate the list is updated
                    MessageBox.Show("COM port list updated");
                }
                else
                {
                    // Show a message indicating no ports were found
                    MessageBox.Show("No COM ports found");
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occurred during port retrieval
                MessageBox.Show($"Error retrieving COM ports: {ex.Message}");
            }
        }

        private void btnUpdateComPorts_Click(object sender, EventArgs e)
        {
           UpdateComPortsList();
        }

        private void btnUpdateComPorts_MouseDown(object sender, MouseEventArgs e)
        {
            // Change button color on mouse down
            btnUpdateComPorts.BackColor = Color.Green; // color change to green
        }

        private void btnUpdateComPorts_MouseUp(object sender, MouseEventArgs e)
        {
            // Change button color on mouse up
            btnUpdateComPorts.BackColor = Color.Snow; // Restore to default or any other color

        }

        private void btnConnect_MouseDown(object sender, MouseEventArgs e)
        {
            // Change button color on mouse down
            btnConnect.BackColor = Color.Green;
        }

        private void btnConnect_MouseUp(object sender, MouseEventArgs e)
        {
            btnConnect.BackColor = Color.Snow;

        }

        private void btnDisconnect_MouseDown(object sender, MouseEventArgs e)
        {
            btnDisconnect.BackColor = Color.Green;
        }

        private void btnDisconnect_MouseUp(object sender, MouseEventArgs e)
        {
            btnDisconnect.BackColor= Color.Snow;
        }

        private void btnStartToSendData_MouseDown(object sender, MouseEventArgs e)
        {
            btnStartToSendData.BackColor = Color.Green;
        }

        private void btnStartToSendData_MouseUp(object sender, MouseEventArgs e)
        {
            btnStartToSendData.BackColor= Color.Snow;
        }

        private void btnStopData_MouseDown(object sender, MouseEventArgs e)
        {
            btnStopData.BackColor = Color.Green;
        }

        private void btnStopData_MouseUp(object sender, MouseEventArgs e)
        {
            btnStopData.BackColor= Color.Snow;
        }

        private void btnGenerateTestReport_MouseDown(object sender, MouseEventArgs e)
        {
            btnGenerateTestReport.BackColor = Color.Green;
        }

        private void btnGenerateTestReport_MouseUp(object sender, MouseEventArgs e)
        {
            btnGenerateTestReport.BackColor= Color.Snow;
        }

        private void btnExitForm_MouseDown(object sender, MouseEventArgs e)
        {
            btnExitForm.BackColor= Color.Green;
        }

        private void btnExitForm_MouseUp(object sender, MouseEventArgs e)
        {
            btnExitForm.BackColor = Color.Snow;
        }

        private void btnClearTextBoxData_MouseDown(object sender, MouseEventArgs e)
        {
            btnClearTextBoxData.BackColor = Color.Green;
        }

        private void btnClearTextBoxData_MouseUp(object sender, MouseEventArgs e)
        {
            btnClearTextBoxData.BackColor= Color.Snow;
        }
       
        private void btnClearTextBoxData_Click(object sender, EventArgs e)
        {
            // Call the method to clear text boxes
            clrData.ClearTextBoxData(
                txtLogEthLbk1Tx,
                txtLogEthLbk1Rx,
                txtLogEthLbk2Tx,
                txtLogEthLbk2Rx,
                txtLogMILTx,
                txtLogMILRx);
        }
    }
}
