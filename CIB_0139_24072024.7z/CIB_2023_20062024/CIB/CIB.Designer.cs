﻿
namespace CIB
{
    partial class CIB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CIB));
            this.panelDateTimeDay = new System.Windows.Forms.Panel();
            this.lblDay = new System.Windows.Forms.Label();
            this.lblDateValue = new System.Windows.Forms.Label();
            this.lblTimeValue = new System.Windows.Forms.Label();
            this.timerDateDayTime = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gbGeneralSetting = new System.Windows.Forms.GroupBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.txtTesterName = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbTestSelection = new System.Windows.Forms.GroupBox();
            this.checkBoxEthernetToMIL = new System.Windows.Forms.CheckBox();
            this.checkBoxSerialToEthernet = new System.Windows.Forms.CheckBox();
            this.checkBoxEthernetSerial = new System.Windows.Forms.CheckBox();
            this.checkBoxMilToEthernet = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gbEM1MilSettings = new System.Windows.Forms.GroupBox();
            this.cbEM1SubRTAddr = new System.Windows.Forms.ComboBox();
            this.lbEM1SubRtAddr = new System.Windows.Forms.Label();
            this.cbEM1RtAddr = new System.Windows.Forms.ComboBox();
            this.cbEM1SelChannel = new System.Windows.Forms.ComboBox();
            this.lbEM1RtAddr = new System.Windows.Forms.Label();
            this.lbEM1SelChannel = new System.Windows.Forms.Label();
            this.lbEM1DevNum = new System.Windows.Forms.Label();
            this.cbEM1DevNum = new System.Windows.Forms.ComboBox();
            this.gbEthernetMil1Setting = new System.Windows.Forms.GroupBox();
            this.tbEM1PortNum = new System.Windows.Forms.RichTextBox();
            this.tbEM1ApAddr = new System.Windows.Forms.RichTextBox();
            this.lbEM1TransmitPort = new System.Windows.Forms.Label();
            this.lbEM1IpAddr = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.txtrxelPortNo = new System.Windows.Forms.RichTextBox();
            this.lblrxelPortNo = new System.Windows.Forms.Label();
            this.txtelIPAddress = new System.Windows.Forms.RichTextBox();
            this.lbltxelPortNo = new System.Windows.Forms.Label();
            this.lblelIPAddress = new System.Windows.Forms.Label();
            this.gbEthernetCommuncationSettingel2 = new System.Windows.Forms.GroupBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.txtReceivePortno2el2 = new System.Windows.Forms.RichTextBox();
            this.lblReceivePortNo2el2 = new System.Windows.Forms.Label();
            this.txtel2IPAddress = new System.Windows.Forms.RichTextBox();
            this.lblTransmitPortNo1el2 = new System.Windows.Forms.Label();
            this.lblIPAddressel2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnUpdateComPorts = new System.Windows.Forms.Button();
            this.lblComPort = new System.Windows.Forms.Label();
            this.lblBaudRate = new System.Windows.Forms.Label();
            this.lblDataBits = new System.Windows.Forms.Label();
            this.cBoxPARITYBITS = new System.Windows.Forms.ComboBox();
            this.cBoxDATABITS = new System.Windows.Forms.ComboBox();
            this.cBoxSTOPBITS = new System.Windows.Forms.ComboBox();
            this.cBoxBAUDRATE = new System.Windows.Forms.ComboBox();
            this.lblPARITYBITS = new System.Windows.Forms.Label();
            this.lblStopBits = new System.Windows.Forms.Label();
            this.cBoxCOMPORT = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gbTestSettingsETM = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.lblSerialTestResult = new System.Windows.Forms.Label();
            this.gbTXRXMILCount = new System.Windows.Forms.GroupBox();
            this.txtethMILINBytes = new System.Windows.Forms.RichTextBox();
            this.txtMILDataOutBytes = new System.Windows.Forms.RichTextBox();
            this.lblTXMILDataIN = new System.Windows.Forms.Label();
            this.lblTXMILDataOut = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtLogMILRx = new System.Windows.Forms.RichTextBox();
            this.txtLogMILTx = new System.Windows.Forms.RichTextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtethDataINBytes = new System.Windows.Forms.RichTextBox();
            this.txtethDataOutBytes = new System.Windows.Forms.RichTextBox();
            this.lblEthernetDataInLength = new System.Windows.Forms.Label();
            this.lblEthernetDataOutLength = new System.Windows.Forms.Label();
            this.gbLogWindowSerial = new System.Windows.Forms.GroupBox();
            this.txtLogEthLbk1Rx = new System.Windows.Forms.RichTextBox();
            this.txtLogEthLbk1Tx = new System.Windows.Forms.RichTextBox();
            this.gbTXRXSerialCount = new System.Windows.Forms.GroupBox();
            this.txtSPDataInBytes = new System.Windows.Forms.RichTextBox();
            this.txtSPDataOutBytes = new System.Windows.Forms.RichTextBox();
            this.lblSPDataInLength = new System.Windows.Forms.Label();
            this.lblSPDataOutLength = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtLogEthLbk2Rx = new System.Windows.Forms.RichTextBox();
            this.txtLogEthLbk2Tx = new System.Windows.Forms.RichTextBox();
            this.gbSelectTest = new System.Windows.Forms.GroupBox();
            this.gbOptionsToSelect = new System.Windows.Forms.GroupBox();
            this.btnGenerateTestReport = new System.Windows.Forms.Button();
            this.btnClearTextBoxData = new System.Windows.Forms.Button();
            this.btnStopData = new System.Windows.Forms.Button();
            this.btnExitForm = new System.Windows.Forms.Button();
            this.btnStartToSendData = new System.Windows.Forms.Button();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.panelRight = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelDateTimeDay.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.gbGeneralSetting.SuspendLayout();
            this.gbTestSelection.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbEM1MilSettings.SuspendLayout();
            this.gbEthernetMil1Setting.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.gbEthernetCommuncationSettingel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.gbTestSettingsETM.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.gbTXRXMILCount.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.gbLogWindowSerial.SuspendLayout();
            this.gbTXRXSerialCount.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.gbSelectTest.SuspendLayout();
            this.gbOptionsToSelect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelDateTimeDay
            // 
            this.panelDateTimeDay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelDateTimeDay.BackColor = System.Drawing.SystemColors.Info;
            this.panelDateTimeDay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panelDateTimeDay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelDateTimeDay.Controls.Add(this.lblDay);
            this.panelDateTimeDay.Controls.Add(this.lblDateValue);
            this.panelDateTimeDay.Controls.Add(this.lblTimeValue);
            this.panelDateTimeDay.Location = new System.Drawing.Point(891, 26);
            this.panelDateTimeDay.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDateTimeDay.Name = "panelDateTimeDay";
            this.panelDateTimeDay.Size = new System.Drawing.Size(301, 32);
            this.panelDateTimeDay.TabIndex = 5;
            // 
            // lblDay
            // 
            this.lblDay.AutoSize = true;
            this.lblDay.Location = new System.Drawing.Point(114, 11);
            this.lblDay.Name = "lblDay";
            this.lblDay.Size = new System.Drawing.Size(30, 17);
            this.lblDay.TabIndex = 2;
            this.lblDay.Text = "Day";
            // 
            // lblDateValue
            // 
            this.lblDateValue.AutoSize = true;
            this.lblDateValue.Location = new System.Drawing.Point(210, 11);
            this.lblDateValue.Name = "lblDateValue";
            this.lblDateValue.Size = new System.Drawing.Size(35, 17);
            this.lblDateValue.TabIndex = 1;
            this.lblDateValue.Text = "Date";
            // 
            // lblTimeValue
            // 
            this.lblTimeValue.AutoSize = true;
            this.lblTimeValue.Location = new System.Drawing.Point(12, 11);
            this.lblTimeValue.Name = "lblTimeValue";
            this.lblTimeValue.Size = new System.Drawing.Size(36, 17);
            this.lblTimeValue.TabIndex = 0;
            this.lblTimeValue.Text = "Time";
            // 
            // timerDateDayTime
            // 
            this.timerDateDayTime.Interval = 1000;
            this.timerDateDayTime.Tick += new System.EventHandler(this.timerDateDayTime_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.tabControl1.ItemSize = new System.Drawing.Size(135, 29);
            this.tabControl1.Location = new System.Drawing.Point(12, 72);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(9, 6);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.ShowToolTips = true;
            this.tabControl1.Size = new System.Drawing.Size(1188, 597);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AllowDrop = true;
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.gbGeneralSetting);
            this.tabPage1.Controls.Add(this.gbTestSelection);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.gbEthernetCommuncationSettingel2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 33);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1180, 560);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Configuration Setting";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // gbGeneralSetting
            // 
            this.gbGeneralSetting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbGeneralSetting.Controls.Add(this.richTextBox3);
            this.gbGeneralSetting.Controls.Add(this.richTextBox2);
            this.gbGeneralSetting.Controls.Add(this.richTextBox1);
            this.gbGeneralSetting.Controls.Add(this.txtTesterName);
            this.gbGeneralSetting.Controls.Add(this.label4);
            this.gbGeneralSetting.Controls.Add(this.label3);
            this.gbGeneralSetting.Controls.Add(this.label2);
            this.gbGeneralSetting.Controls.Add(this.label1);
            this.gbGeneralSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbGeneralSetting.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbGeneralSetting.Location = new System.Drawing.Point(19, 38);
            this.gbGeneralSetting.Name = "gbGeneralSetting";
            this.gbGeneralSetting.Size = new System.Drawing.Size(231, 209);
            this.gbGeneralSetting.TabIndex = 61;
            this.gbGeneralSetting.TabStop = false;
            this.gbGeneralSetting.Text = "General Setting";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(109, 114);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(104, 84);
            this.richTextBox3.TabIndex = 14;
            this.richTextBox3.Text = "";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(109, 87);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(104, 22);
            this.richTextBox2.TabIndex = 13;
            this.richTextBox2.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(109, 53);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(104, 22);
            this.richTextBox1.TabIndex = 12;
            this.richTextBox1.Text = "";
            // 
            // txtTesterName
            // 
            this.txtTesterName.Location = new System.Drawing.Point(109, 25);
            this.txtTesterName.Name = "txtTesterName";
            this.txtTesterName.Size = new System.Drawing.Size(104, 23);
            this.txtTesterName.TabIndex = 11;
            this.txtTesterName.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.MintCream;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Test Remark";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.MintCream;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Unit Nos-UUT";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.MintCream;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "CIB UNIT";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MintCream;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tester Name";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gbTestSelection
            // 
            this.gbTestSelection.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbTestSelection.Controls.Add(this.checkBoxEthernetToMIL);
            this.gbTestSelection.Controls.Add(this.checkBoxSerialToEthernet);
            this.gbTestSelection.Controls.Add(this.checkBoxEthernetSerial);
            this.gbTestSelection.Controls.Add(this.checkBoxMilToEthernet);
            this.gbTestSelection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbTestSelection.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbTestSelection.Location = new System.Drawing.Point(979, 36);
            this.gbTestSelection.Name = "gbTestSelection";
            this.gbTestSelection.Size = new System.Drawing.Size(191, 166);
            this.gbTestSelection.TabIndex = 60;
            this.gbTestSelection.TabStop = false;
            this.gbTestSelection.Text = "Select Test ";
            // 
            // checkBoxEthernetToMIL
            // 
            this.checkBoxEthernetToMIL.AutoSize = true;
            this.checkBoxEthernetToMIL.Location = new System.Drawing.Point(38, 102);
            this.checkBoxEthernetToMIL.Name = "checkBoxEthernetToMIL";
            this.checkBoxEthernetToMIL.Size = new System.Drawing.Size(114, 21);
            this.checkBoxEthernetToMIL.TabIndex = 33;
            this.checkBoxEthernetToMIL.Text = "Ethernet To MIL";
            this.checkBoxEthernetToMIL.UseVisualStyleBackColor = true;
            // 
            // checkBoxSerialToEthernet
            // 
            this.checkBoxSerialToEthernet.AutoSize = true;
            this.checkBoxSerialToEthernet.Location = new System.Drawing.Point(38, 24);
            this.checkBoxSerialToEthernet.Name = "checkBoxSerialToEthernet";
            this.checkBoxSerialToEthernet.Size = new System.Drawing.Size(123, 21);
            this.checkBoxSerialToEthernet.TabIndex = 31;
            this.checkBoxSerialToEthernet.Text = "Serial To Ethernet";
            this.checkBoxSerialToEthernet.UseVisualStyleBackColor = true;
            // 
            // checkBoxEthernetSerial
            // 
            this.checkBoxEthernetSerial.AutoSize = true;
            this.checkBoxEthernetSerial.Location = new System.Drawing.Point(38, 51);
            this.checkBoxEthernetSerial.Name = "checkBoxEthernetSerial";
            this.checkBoxEthernetSerial.Size = new System.Drawing.Size(107, 21);
            this.checkBoxEthernetSerial.TabIndex = 30;
            this.checkBoxEthernetSerial.Text = "Ethernet-Serial";
            this.checkBoxEthernetSerial.UseVisualStyleBackColor = true;
            // 
            // checkBoxMilToEthernet
            // 
            this.checkBoxMilToEthernet.AutoSize = true;
            this.checkBoxMilToEthernet.Location = new System.Drawing.Point(38, 78);
            this.checkBoxMilToEthernet.Name = "checkBoxMilToEthernet";
            this.checkBoxMilToEthernet.Size = new System.Drawing.Size(111, 21);
            this.checkBoxMilToEthernet.TabIndex = 29;
            this.checkBoxMilToEthernet.Text = "Mil To Ethernet";
            this.checkBoxMilToEthernet.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox5.Controls.Add(this.btnConnect);
            this.groupBox5.Controls.Add(this.btnDisconnect);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(981, 277);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(189, 91);
            this.groupBox5.TabIndex = 58;
            this.groupBox5.TabStop = false;
            // 
            // btnConnect
            // 
            this.btnConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConnect.BackColor = System.Drawing.Color.Snow;
            this.btnConnect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnConnect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConnect.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.Location = new System.Drawing.Point(6, 24);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(87, 37);
            this.btnConnect.TabIndex = 54;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnConnect_MouseDown);
            this.btnConnect.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnConnect_MouseUp);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDisconnect.BackColor = System.Drawing.Color.Snow;
            this.btnDisconnect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDisconnect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDisconnect.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisconnect.Location = new System.Drawing.Point(99, 24);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(79, 37);
            this.btnDisconnect.TabIndex = 57;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = false;
            this.btnDisconnect.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnDisconnect_MouseDown);
            this.btnDisconnect.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnDisconnect_MouseUp);
            // 
            // groupBox4
            // 
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox4.Controls.Add(this.radioButton1);
            this.groupBox4.Controls.Add(this.radioButton2);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(979, 208);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(191, 63);
            this.groupBox4.TabIndex = 53;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Select Mode";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButton1.Location = new System.Drawing.Point(79, 30);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(52, 21);
            this.radioButton1.TabIndex = 1;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Auto";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.radioButton2.Location = new System.Drawing.Point(13, 29);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(68, 21);
            this.radioButton2.TabIndex = 0;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Manual";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox2.Controls.Add(this.gbEM1MilSettings);
            this.groupBox2.Controls.Add(this.gbEthernetMil1Setting);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Location = new System.Drawing.Point(19, 253);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(947, 115);
            this.groupBox2.TabIndex = 51;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ethernet MIL Loopback ";
            // 
            // gbEM1MilSettings
            // 
            this.gbEM1MilSettings.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbEM1MilSettings.Controls.Add(this.cbEM1SubRTAddr);
            this.gbEM1MilSettings.Controls.Add(this.lbEM1SubRtAddr);
            this.gbEM1MilSettings.Controls.Add(this.cbEM1RtAddr);
            this.gbEM1MilSettings.Controls.Add(this.cbEM1SelChannel);
            this.gbEM1MilSettings.Controls.Add(this.lbEM1RtAddr);
            this.gbEM1MilSettings.Controls.Add(this.lbEM1SelChannel);
            this.gbEM1MilSettings.Controls.Add(this.lbEM1DevNum);
            this.gbEM1MilSettings.Controls.Add(this.cbEM1DevNum);
            this.gbEM1MilSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbEM1MilSettings.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbEM1MilSettings.Location = new System.Drawing.Point(380, 24);
            this.gbEM1MilSettings.Name = "gbEM1MilSettings";
            this.gbEM1MilSettings.Size = new System.Drawing.Size(561, 85);
            this.gbEM1MilSettings.TabIndex = 50;
            this.gbEM1MilSettings.TabStop = false;
            this.gbEM1MilSettings.Text = "Mil -1553 Settings";
            // 
            // cbEM1SubRTAddr
            // 
            this.cbEM1SubRTAddr.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbEM1SubRTAddr.BackColor = System.Drawing.Color.LightGray;
            this.cbEM1SubRTAddr.DropDownHeight = 65;
            this.cbEM1SubRTAddr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEM1SubRTAddr.DropDownWidth = 70;
            this.cbEM1SubRTAddr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbEM1SubRTAddr.FormattingEnabled = true;
            this.cbEM1SubRTAddr.IntegralHeight = false;
            this.cbEM1SubRTAddr.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.cbEM1SubRTAddr.Location = new System.Drawing.Point(416, 53);
            this.cbEM1SubRTAddr.Name = "cbEM1SubRTAddr";
            this.cbEM1SubRTAddr.Size = new System.Drawing.Size(115, 25);
            this.cbEM1SubRTAddr.TabIndex = 35;
            // 
            // lbEM1SubRtAddr
            // 
            this.lbEM1SubRtAddr.AutoSize = true;
            this.lbEM1SubRtAddr.BackColor = System.Drawing.Color.MintCream;
            this.lbEM1SubRtAddr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbEM1SubRtAddr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEM1SubRtAddr.Location = new System.Drawing.Point(416, 21);
            this.lbEM1SubRtAddr.Name = "lbEM1SubRtAddr";
            this.lbEM1SubRtAddr.Size = new System.Drawing.Size(132, 19);
            this.lbEM1SubRtAddr.TabIndex = 34;
            this.lbEM1SubRtAddr.Text = "Select Sub RT Address";
            // 
            // cbEM1RtAddr
            // 
            this.cbEM1RtAddr.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbEM1RtAddr.BackColor = System.Drawing.Color.LightGray;
            this.cbEM1RtAddr.DropDownHeight = 65;
            this.cbEM1RtAddr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEM1RtAddr.DropDownWidth = 70;
            this.cbEM1RtAddr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbEM1RtAddr.FormattingEnabled = true;
            this.cbEM1RtAddr.IntegralHeight = false;
            this.cbEM1RtAddr.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.cbEM1RtAddr.Location = new System.Drawing.Point(293, 53);
            this.cbEM1RtAddr.Name = "cbEM1RtAddr";
            this.cbEM1RtAddr.Size = new System.Drawing.Size(94, 25);
            this.cbEM1RtAddr.TabIndex = 33;
            // 
            // cbEM1SelChannel
            // 
            this.cbEM1SelChannel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbEM1SelChannel.BackColor = System.Drawing.Color.LightGray;
            this.cbEM1SelChannel.DropDownHeight = 65;
            this.cbEM1SelChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEM1SelChannel.DropDownWidth = 70;
            this.cbEM1SelChannel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbEM1SelChannel.FormattingEnabled = true;
            this.cbEM1SelChannel.IntegralHeight = false;
            this.cbEM1SelChannel.Items.AddRange(new object[] {
            "A",
            "B"});
            this.cbEM1SelChannel.Location = new System.Drawing.Point(188, 54);
            this.cbEM1SelChannel.Name = "cbEM1SelChannel";
            this.cbEM1SelChannel.Size = new System.Drawing.Size(83, 25);
            this.cbEM1SelChannel.TabIndex = 31;
            // 
            // lbEM1RtAddr
            // 
            this.lbEM1RtAddr.AutoSize = true;
            this.lbEM1RtAddr.BackColor = System.Drawing.Color.MintCream;
            this.lbEM1RtAddr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbEM1RtAddr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEM1RtAddr.Location = new System.Drawing.Point(293, 21);
            this.lbEM1RtAddr.Name = "lbEM1RtAddr";
            this.lbEM1RtAddr.Size = new System.Drawing.Size(108, 19);
            this.lbEM1RtAddr.TabIndex = 32;
            this.lbEM1RtAddr.Text = "Select RT Address";
            // 
            // lbEM1SelChannel
            // 
            this.lbEM1SelChannel.AutoSize = true;
            this.lbEM1SelChannel.BackColor = System.Drawing.Color.MintCream;
            this.lbEM1SelChannel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbEM1SelChannel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEM1SelChannel.Location = new System.Drawing.Point(188, 21);
            this.lbEM1SelChannel.Name = "lbEM1SelChannel";
            this.lbEM1SelChannel.Size = new System.Drawing.Size(96, 19);
            this.lbEM1SelChannel.TabIndex = 30;
            this.lbEM1SelChannel.Text = " Select Channel";
            // 
            // lbEM1DevNum
            // 
            this.lbEM1DevNum.AutoSize = true;
            this.lbEM1DevNum.BackColor = System.Drawing.Color.MintCream;
            this.lbEM1DevNum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbEM1DevNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEM1DevNum.Location = new System.Drawing.Point(35, 21);
            this.lbEM1DevNum.Name = "lbEM1DevNum";
            this.lbEM1DevNum.Size = new System.Drawing.Size(138, 19);
            this.lbEM1DevNum.TabIndex = 28;
            this.lbEM1DevNum.Text = " Select Device Number";
            // 
            // cbEM1DevNum
            // 
            this.cbEM1DevNum.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbEM1DevNum.BackColor = System.Drawing.Color.LightGray;
            this.cbEM1DevNum.DropDownHeight = 65;
            this.cbEM1DevNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEM1DevNum.DropDownWidth = 70;
            this.cbEM1DevNum.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbEM1DevNum.FormattingEnabled = true;
            this.cbEM1DevNum.IntegralHeight = false;
            this.cbEM1DevNum.ItemHeight = 17;
            this.cbEM1DevNum.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cbEM1DevNum.Location = new System.Drawing.Point(41, 54);
            this.cbEM1DevNum.MaxDropDownItems = 7;
            this.cbEM1DevNum.Name = "cbEM1DevNum";
            this.cbEM1DevNum.Size = new System.Drawing.Size(129, 25);
            this.cbEM1DevNum.Sorted = true;
            this.cbEM1DevNum.TabIndex = 29;
            // 
            // gbEthernetMil1Setting
            // 
            this.gbEthernetMil1Setting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbEthernetMil1Setting.Controls.Add(this.tbEM1PortNum);
            this.gbEthernetMil1Setting.Controls.Add(this.tbEM1ApAddr);
            this.gbEthernetMil1Setting.Controls.Add(this.lbEM1TransmitPort);
            this.gbEthernetMil1Setting.Controls.Add(this.lbEM1IpAddr);
            this.gbEthernetMil1Setting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbEthernetMil1Setting.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbEthernetMil1Setting.Location = new System.Drawing.Point(6, 24);
            this.gbEthernetMil1Setting.Name = "gbEthernetMil1Setting";
            this.gbEthernetMil1Setting.Size = new System.Drawing.Size(368, 85);
            this.gbEthernetMil1Setting.TabIndex = 48;
            this.gbEthernetMil1Setting.TabStop = false;
            this.gbEthernetMil1Setting.Text = "Ethernet Communication Setting";
            // 
            // tbEM1PortNum
            // 
            this.tbEM1PortNum.Location = new System.Drawing.Point(301, 34);
            this.tbEM1PortNum.Name = "tbEM1PortNum";
            this.tbEM1PortNum.Size = new System.Drawing.Size(43, 22);
            this.tbEM1PortNum.TabIndex = 3;
            this.tbEM1PortNum.Text = "19932";
            // 
            // tbEM1ApAddr
            // 
            this.tbEM1ApAddr.Location = new System.Drawing.Point(88, 34);
            this.tbEM1ApAddr.Name = "tbEM1ApAddr";
            this.tbEM1ApAddr.Size = new System.Drawing.Size(84, 22);
            this.tbEM1ApAddr.TabIndex = 2;
            this.tbEM1ApAddr.Text = "192.168.1.80";
            // 
            // lbEM1TransmitPort
            // 
            this.lbEM1TransmitPort.AutoSize = true;
            this.lbEM1TransmitPort.BackColor = System.Drawing.Color.MintCream;
            this.lbEM1TransmitPort.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbEM1TransmitPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEM1TransmitPort.Location = new System.Drawing.Point(181, 37);
            this.lbEM1TransmitPort.Name = "lbEM1TransmitPort";
            this.lbEM1TransmitPort.Size = new System.Drawing.Size(101, 19);
            this.lbEM1TransmitPort.TabIndex = 1;
            this.lbEM1TransmitPort.Text = "Transmit Port No";
            // 
            // lbEM1IpAddr
            // 
            this.lbEM1IpAddr.AutoSize = true;
            this.lbEM1IpAddr.BackColor = System.Drawing.Color.MintCream;
            this.lbEM1IpAddr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbEM1IpAddr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbEM1IpAddr.Location = new System.Drawing.Point(14, 37);
            this.lbEM1IpAddr.Name = "lbEM1IpAddr";
            this.lbEM1IpAddr.Size = new System.Drawing.Size(67, 19);
            this.lbEM1IpAddr.TabIndex = 0;
            this.lbEM1IpAddr.Text = "IP Address";
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox3.Controls.Add(this.richTextBox7);
            this.groupBox3.Controls.Add(this.txtrxelPortNo);
            this.groupBox3.Controls.Add(this.lblrxelPortNo);
            this.groupBox3.Controls.Add(this.txtelIPAddress);
            this.groupBox3.Controls.Add(this.lbltxelPortNo);
            this.groupBox3.Controls.Add(this.lblelIPAddress);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(265, 125);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(701, 62);
            this.groupBox3.TabIndex = 47;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ethernet Loopback 1";
            // 
            // richTextBox7
            // 
            this.richTextBox7.Location = new System.Drawing.Point(340, 27);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(104, 22);
            this.richTextBox7.TabIndex = 33;
            this.richTextBox7.Text = "4001";
            // 
            // txtrxelPortNo
            // 
            this.txtrxelPortNo.Location = new System.Drawing.Point(577, 27);
            this.txtrxelPortNo.Name = "txtrxelPortNo";
            this.txtrxelPortNo.Size = new System.Drawing.Size(104, 22);
            this.txtrxelPortNo.TabIndex = 32;
            this.txtrxelPortNo.Text = "4001";
            // 
            // lblrxelPortNo
            // 
            this.lblrxelPortNo.AutoSize = true;
            this.lblrxelPortNo.BackColor = System.Drawing.Color.MintCream;
            this.lblrxelPortNo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblrxelPortNo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblrxelPortNo.Location = new System.Drawing.Point(474, 27);
            this.lblrxelPortNo.Name = "lblrxelPortNo";
            this.lblrxelPortNo.Size = new System.Drawing.Size(99, 19);
            this.lblrxelPortNo.TabIndex = 31;
            this.lblrxelPortNo.Text = "Receive Port No";
            // 
            // txtelIPAddress
            // 
            this.txtelIPAddress.Location = new System.Drawing.Point(96, 28);
            this.txtelIPAddress.Name = "txtelIPAddress";
            this.txtelIPAddress.Size = new System.Drawing.Size(110, 22);
            this.txtelIPAddress.TabIndex = 2;
            this.txtelIPAddress.Text = "192.168.1.254";
            // 
            // lbltxelPortNo
            // 
            this.lbltxelPortNo.AutoSize = true;
            this.lbltxelPortNo.BackColor = System.Drawing.Color.MintCream;
            this.lbltxelPortNo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbltxelPortNo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbltxelPortNo.Location = new System.Drawing.Point(235, 27);
            this.lbltxelPortNo.Name = "lbltxelPortNo";
            this.lbltxelPortNo.Size = new System.Drawing.Size(101, 19);
            this.lbltxelPortNo.TabIndex = 1;
            this.lbltxelPortNo.Text = "Transmit Port No";
            // 
            // lblelIPAddress
            // 
            this.lblelIPAddress.AutoSize = true;
            this.lblelIPAddress.BackColor = System.Drawing.Color.MintCream;
            this.lblelIPAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblelIPAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblelIPAddress.Location = new System.Drawing.Point(25, 28);
            this.lblelIPAddress.Name = "lblelIPAddress";
            this.lblelIPAddress.Size = new System.Drawing.Size(67, 19);
            this.lblelIPAddress.TabIndex = 0;
            this.lblelIPAddress.Text = "IP Address";
            // 
            // gbEthernetCommuncationSettingel2
            // 
            this.gbEthernetCommuncationSettingel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbEthernetCommuncationSettingel2.Controls.Add(this.richTextBox8);
            this.gbEthernetCommuncationSettingel2.Controls.Add(this.txtReceivePortno2el2);
            this.gbEthernetCommuncationSettingel2.Controls.Add(this.lblReceivePortNo2el2);
            this.gbEthernetCommuncationSettingel2.Controls.Add(this.txtel2IPAddress);
            this.gbEthernetCommuncationSettingel2.Controls.Add(this.lblTransmitPortNo1el2);
            this.gbEthernetCommuncationSettingel2.Controls.Add(this.lblIPAddressel2);
            this.gbEthernetCommuncationSettingel2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbEthernetCommuncationSettingel2.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbEthernetCommuncationSettingel2.Location = new System.Drawing.Point(265, 193);
            this.gbEthernetCommuncationSettingel2.Name = "gbEthernetCommuncationSettingel2";
            this.gbEthernetCommuncationSettingel2.Size = new System.Drawing.Size(701, 54);
            this.gbEthernetCommuncationSettingel2.TabIndex = 46;
            this.gbEthernetCommuncationSettingel2.TabStop = false;
            this.gbEthernetCommuncationSettingel2.Text = "Ethernet Loopback 2";
            // 
            // richTextBox8
            // 
            this.richTextBox8.Location = new System.Drawing.Point(338, 24);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(104, 22);
            this.richTextBox8.TabIndex = 34;
            this.richTextBox8.Text = "4002";
            // 
            // txtReceivePortno2el2
            // 
            this.txtReceivePortno2el2.Location = new System.Drawing.Point(577, 24);
            this.txtReceivePortno2el2.Name = "txtReceivePortno2el2";
            this.txtReceivePortno2el2.Size = new System.Drawing.Size(104, 22);
            this.txtReceivePortno2el2.TabIndex = 32;
            this.txtReceivePortno2el2.Text = "4002";
            // 
            // lblReceivePortNo2el2
            // 
            this.lblReceivePortNo2el2.AutoSize = true;
            this.lblReceivePortNo2el2.BackColor = System.Drawing.Color.MintCream;
            this.lblReceivePortNo2el2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblReceivePortNo2el2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblReceivePortNo2el2.Location = new System.Drawing.Point(472, 27);
            this.lblReceivePortNo2el2.Name = "lblReceivePortNo2el2";
            this.lblReceivePortNo2el2.Size = new System.Drawing.Size(99, 19);
            this.lblReceivePortNo2el2.TabIndex = 31;
            this.lblReceivePortNo2el2.Text = "Receive Port No";
            // 
            // txtel2IPAddress
            // 
            this.txtel2IPAddress.Location = new System.Drawing.Point(96, 21);
            this.txtel2IPAddress.Name = "txtel2IPAddress";
            this.txtel2IPAddress.Size = new System.Drawing.Size(110, 22);
            this.txtel2IPAddress.TabIndex = 2;
            this.txtel2IPAddress.Text = "192.168.1.254";
            // 
            // lblTransmitPortNo1el2
            // 
            this.lblTransmitPortNo1el2.AutoSize = true;
            this.lblTransmitPortNo1el2.BackColor = System.Drawing.Color.MintCream;
            this.lblTransmitPortNo1el2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTransmitPortNo1el2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblTransmitPortNo1el2.Location = new System.Drawing.Point(235, 26);
            this.lblTransmitPortNo1el2.Name = "lblTransmitPortNo1el2";
            this.lblTransmitPortNo1el2.Size = new System.Drawing.Size(101, 19);
            this.lblTransmitPortNo1el2.TabIndex = 1;
            this.lblTransmitPortNo1el2.Text = "Transmit Port No";
            // 
            // lblIPAddressel2
            // 
            this.lblIPAddressel2.AutoSize = true;
            this.lblIPAddressel2.BackColor = System.Drawing.Color.MintCream;
            this.lblIPAddressel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblIPAddressel2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblIPAddressel2.Location = new System.Drawing.Point(25, 26);
            this.lblIPAddressel2.Name = "lblIPAddressel2";
            this.lblIPAddressel2.Size = new System.Drawing.Size(67, 19);
            this.lblIPAddressel2.TabIndex = 0;
            this.lblIPAddressel2.Text = "IP Address";
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox1.Controls.Add(this.btnUpdateComPorts);
            this.groupBox1.Controls.Add(this.lblComPort);
            this.groupBox1.Controls.Add(this.lblBaudRate);
            this.groupBox1.Controls.Add(this.lblDataBits);
            this.groupBox1.Controls.Add(this.cBoxPARITYBITS);
            this.groupBox1.Controls.Add(this.cBoxDATABITS);
            this.groupBox1.Controls.Add(this.cBoxSTOPBITS);
            this.groupBox1.Controls.Add(this.cBoxBAUDRATE);
            this.groupBox1.Controls.Add(this.lblPARITYBITS);
            this.groupBox1.Controls.Add(this.lblStopBits);
            this.groupBox1.Controls.Add(this.cBoxCOMPORT);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(265, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(701, 81);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Serial Port Communication Setting";
            // 
            // btnUpdateComPorts
            // 
            this.btnUpdateComPorts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateComPorts.AutoSize = true;
            this.btnUpdateComPorts.BackColor = System.Drawing.Color.Snow;
            this.btnUpdateComPorts.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateComPorts.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateComPorts.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUpdateComPorts.Location = new System.Drawing.Point(494, 33);
            this.btnUpdateComPorts.Name = "btnUpdateComPorts";
            this.btnUpdateComPorts.Size = new System.Drawing.Size(129, 37);
            this.btnUpdateComPorts.TabIndex = 24;
            this.btnUpdateComPorts.Text = "Update Com Ports";
            this.btnUpdateComPorts.UseVisualStyleBackColor = false;
            this.btnUpdateComPorts.Click += new System.EventHandler(this.btnUpdateComPorts_Click);
            this.btnUpdateComPorts.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnUpdateComPorts_MouseDown);
            this.btnUpdateComPorts.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnUpdateComPorts_MouseUp);
            // 
            // lblComPort
            // 
            this.lblComPort.AutoSize = true;
            this.lblComPort.BackColor = System.Drawing.Color.MintCream;
            this.lblComPort.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblComPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblComPort.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComPort.Location = new System.Drawing.Point(19, 25);
            this.lblComPort.Name = "lblComPort";
            this.lblComPort.Size = new System.Drawing.Size(74, 19);
            this.lblComPort.TabIndex = 10;
            this.lblComPort.Text = "COM PORT";
            // 
            // lblBaudRate
            // 
            this.lblBaudRate.AutoSize = true;
            this.lblBaudRate.BackColor = System.Drawing.Color.MintCream;
            this.lblBaudRate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblBaudRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblBaudRate.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaudRate.Location = new System.Drawing.Point(112, 25);
            this.lblBaudRate.Name = "lblBaudRate";
            this.lblBaudRate.Size = new System.Drawing.Size(74, 19);
            this.lblBaudRate.TabIndex = 14;
            this.lblBaudRate.Text = "BAUD RATE";
            // 
            // lblDataBits
            // 
            this.lblDataBits.AutoSize = true;
            this.lblDataBits.BackColor = System.Drawing.Color.MintCream;
            this.lblDataBits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDataBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblDataBits.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataBits.Location = new System.Drawing.Point(205, 25);
            this.lblDataBits.Name = "lblDataBits";
            this.lblDataBits.Size = new System.Drawing.Size(67, 19);
            this.lblDataBits.TabIndex = 13;
            this.lblDataBits.Text = "DATA BITS";
            // 
            // cBoxPARITYBITS
            // 
            this.cBoxPARITYBITS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cBoxPARITYBITS.BackColor = System.Drawing.Color.LightGray;
            this.cBoxPARITYBITS.DropDownHeight = 65;
            this.cBoxPARITYBITS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxPARITYBITS.DropDownWidth = 70;
            this.cBoxPARITYBITS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cBoxPARITYBITS.FormattingEnabled = true;
            this.cBoxPARITYBITS.IntegralHeight = false;
            this.cBoxPARITYBITS.Items.AddRange(new object[] {
            "Even",
            "None",
            "Odd"});
            this.cBoxPARITYBITS.Location = new System.Drawing.Point(381, 50);
            this.cBoxPARITYBITS.Name = "cBoxPARITYBITS";
            this.cBoxPARITYBITS.Size = new System.Drawing.Size(80, 25);
            this.cBoxPARITYBITS.Sorted = true;
            this.cBoxPARITYBITS.TabIndex = 17;
            // 
            // cBoxDATABITS
            // 
            this.cBoxDATABITS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cBoxDATABITS.BackColor = System.Drawing.Color.LightGray;
            this.cBoxDATABITS.DropDownHeight = 65;
            this.cBoxDATABITS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxDATABITS.DropDownWidth = 70;
            this.cBoxDATABITS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cBoxDATABITS.FormattingEnabled = true;
            this.cBoxDATABITS.IntegralHeight = false;
            this.cBoxDATABITS.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.cBoxDATABITS.Location = new System.Drawing.Point(203, 50);
            this.cBoxDATABITS.Name = "cBoxDATABITS";
            this.cBoxDATABITS.Size = new System.Drawing.Size(69, 25);
            this.cBoxDATABITS.Sorted = true;
            this.cBoxDATABITS.TabIndex = 18;
            // 
            // cBoxSTOPBITS
            // 
            this.cBoxSTOPBITS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cBoxSTOPBITS.BackColor = System.Drawing.Color.LightGray;
            this.cBoxSTOPBITS.DropDownHeight = 65;
            this.cBoxSTOPBITS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxSTOPBITS.DropDownWidth = 70;
            this.cBoxSTOPBITS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cBoxSTOPBITS.FormattingEnabled = true;
            this.cBoxSTOPBITS.IntegralHeight = false;
            this.cBoxSTOPBITS.Items.AddRange(new object[] {
            "One",
            "Two"});
            this.cBoxSTOPBITS.Location = new System.Drawing.Point(292, 49);
            this.cBoxSTOPBITS.Name = "cBoxSTOPBITS";
            this.cBoxSTOPBITS.Size = new System.Drawing.Size(67, 25);
            this.cBoxSTOPBITS.Sorted = true;
            this.cBoxSTOPBITS.TabIndex = 16;
            // 
            // cBoxBAUDRATE
            // 
            this.cBoxBAUDRATE.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cBoxBAUDRATE.BackColor = System.Drawing.Color.LightGray;
            this.cBoxBAUDRATE.DropDownHeight = 65;
            this.cBoxBAUDRATE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxBAUDRATE.DropDownWidth = 70;
            this.cBoxBAUDRATE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cBoxBAUDRATE.FormattingEnabled = true;
            this.cBoxBAUDRATE.IntegralHeight = false;
            this.cBoxBAUDRATE.Items.AddRange(new object[] {
            "115200",
            "2400",
            "4800",
            "9600"});
            this.cBoxBAUDRATE.Location = new System.Drawing.Point(110, 50);
            this.cBoxBAUDRATE.Name = "cBoxBAUDRATE";
            this.cBoxBAUDRATE.Size = new System.Drawing.Size(76, 25);
            this.cBoxBAUDRATE.Sorted = true;
            this.cBoxBAUDRATE.TabIndex = 19;
            // 
            // lblPARITYBITS
            // 
            this.lblPARITYBITS.AutoSize = true;
            this.lblPARITYBITS.BackColor = System.Drawing.Color.MintCream;
            this.lblPARITYBITS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPARITYBITS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPARITYBITS.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPARITYBITS.Location = new System.Drawing.Point(383, 24);
            this.lblPARITYBITS.Name = "lblPARITYBITS";
            this.lblPARITYBITS.Size = new System.Drawing.Size(74, 19);
            this.lblPARITYBITS.TabIndex = 11;
            this.lblPARITYBITS.Text = "PARITY BITS";
            // 
            // lblStopBits
            // 
            this.lblStopBits.AutoSize = true;
            this.lblStopBits.BackColor = System.Drawing.Color.MintCream;
            this.lblStopBits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblStopBits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblStopBits.Font = new System.Drawing.Font("Segoe UI Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStopBits.Location = new System.Drawing.Point(294, 25);
            this.lblStopBits.Name = "lblStopBits";
            this.lblStopBits.Size = new System.Drawing.Size(66, 19);
            this.lblStopBits.TabIndex = 12;
            this.lblStopBits.Text = "STOP BITS";
            // 
            // cBoxCOMPORT
            // 
            this.cBoxCOMPORT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cBoxCOMPORT.BackColor = System.Drawing.Color.LightGray;
            this.cBoxCOMPORT.DropDownHeight = 65;
            this.cBoxCOMPORT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBoxCOMPORT.DropDownWidth = 70;
            this.cBoxCOMPORT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cBoxCOMPORT.FormattingEnabled = true;
            this.cBoxCOMPORT.IntegralHeight = false;
            this.cBoxCOMPORT.Location = new System.Drawing.Point(21, 50);
            this.cBoxCOMPORT.Name = "cBoxCOMPORT";
            this.cBoxCOMPORT.Size = new System.Drawing.Size(69, 25);
            this.cBoxCOMPORT.Sorted = true;
            this.cBoxCOMPORT.TabIndex = 15;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage2.Controls.Add(this.gbTestSettingsETM);
            this.tabPage2.Controls.Add(this.gbSelectTest);
            this.tabPage2.Location = new System.Drawing.Point(4, 33);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(1180, 560);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Environmental Test Mode";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // gbTestSettingsETM
            // 
            this.gbTestSettingsETM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbTestSettingsETM.Controls.Add(this.groupBox6);
            this.gbTestSettingsETM.Controls.Add(this.gbTXRXMILCount);
            this.gbTestSettingsETM.Controls.Add(this.groupBox7);
            this.gbTestSettingsETM.Controls.Add(this.groupBox8);
            this.gbTestSettingsETM.Controls.Add(this.gbLogWindowSerial);
            this.gbTestSettingsETM.Controls.Add(this.gbTXRXSerialCount);
            this.gbTestSettingsETM.Controls.Add(this.groupBox9);
            this.gbTestSettingsETM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbTestSettingsETM.Location = new System.Drawing.Point(9, 88);
            this.gbTestSettingsETM.Name = "gbTestSettingsETM";
            this.gbTestSettingsETM.Size = new System.Drawing.Size(1158, 475);
            this.gbTestSettingsETM.TabIndex = 6;
            this.gbTestSettingsETM.TabStop = false;
            this.gbTestSettingsETM.Text = "Log Windows-TX-RX";
            // 
            // groupBox6
            // 
            this.groupBox6.AutoSize = true;
            this.groupBox6.Controls.Add(this.richTextBox11);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Controls.Add(this.richTextBox10);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.richTextBox9);
            this.groupBox6.Controls.Add(this.lblSerialTestResult);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox6.Location = new System.Drawing.Point(1010, 21);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(142, 426);
            this.groupBox6.TabIndex = 27;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Test Result";
            this.groupBox6.UseCompatibleTextRendering = true;
            // 
            // richTextBox11
            // 
            this.richTextBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.richTextBox11.Location = new System.Drawing.Point(18, 70);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.ReadOnly = true;
            this.richTextBox11.Size = new System.Drawing.Size(93, 26);
            this.richTextBox11.TabIndex = 29;
            this.richTextBox11.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.MintCream;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Location = new System.Drawing.Point(6, 301);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 25);
            this.label6.TabIndex = 27;
            this.label6.Text = "MIL Loopback Result";
            this.label6.UseCompatibleTextRendering = true;
            // 
            // richTextBox10
            // 
            this.richTextBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.richTextBox10.Location = new System.Drawing.Point(18, 343);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.ReadOnly = true;
            this.richTextBox10.Size = new System.Drawing.Size(93, 26);
            this.richTextBox10.TabIndex = 28;
            this.richTextBox10.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.MintCream;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(6, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 25);
            this.label5.TabIndex = 25;
            this.label5.Text = "Loopback 2 Result";
            this.label5.UseCompatibleTextRendering = true;
            // 
            // richTextBox9
            // 
            this.richTextBox9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.richTextBox9.Location = new System.Drawing.Point(18, 202);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.ReadOnly = true;
            this.richTextBox9.Size = new System.Drawing.Size(93, 26);
            this.richTextBox9.TabIndex = 26;
            this.richTextBox9.Text = "";
            // 
            // lblSerialTestResult
            // 
            this.lblSerialTestResult.AutoSize = true;
            this.lblSerialTestResult.BackColor = System.Drawing.Color.MintCream;
            this.lblSerialTestResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSerialTestResult.Location = new System.Drawing.Point(6, 31);
            this.lblSerialTestResult.Name = "lblSerialTestResult";
            this.lblSerialTestResult.Size = new System.Drawing.Size(107, 25);
            this.lblSerialTestResult.TabIndex = 20;
            this.lblSerialTestResult.Text = "Loopback 1 Result";
            this.lblSerialTestResult.UseCompatibleTextRendering = true;
            // 
            // gbTXRXMILCount
            // 
            this.gbTXRXMILCount.AutoSize = true;
            this.gbTXRXMILCount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbTXRXMILCount.Controls.Add(this.txtethMILINBytes);
            this.gbTXRXMILCount.Controls.Add(this.txtMILDataOutBytes);
            this.gbTXRXMILCount.Controls.Add(this.lblTXMILDataIN);
            this.gbTXRXMILCount.Controls.Add(this.lblTXMILDataOut);
            this.gbTXRXMILCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbTXRXMILCount.Location = new System.Drawing.Point(817, 315);
            this.gbTXRXMILCount.Name = "gbTXRXMILCount";
            this.gbTXRXMILCount.Size = new System.Drawing.Size(187, 132);
            this.gbTXRXMILCount.TabIndex = 25;
            this.gbTXRXMILCount.TabStop = false;
            this.gbTXRXMILCount.Text = "TX RX MIL Count";
            // 
            // txtethMILINBytes
            // 
            this.txtethMILINBytes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtethMILINBytes.Location = new System.Drawing.Point(20, 101);
            this.txtethMILINBytes.Name = "txtethMILINBytes";
            this.txtethMILINBytes.Size = new System.Drawing.Size(99, 25);
            this.txtethMILINBytes.TabIndex = 27;
            this.txtethMILINBytes.Text = "";
            // 
            // txtMILDataOutBytes
            // 
            this.txtMILDataOutBytes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMILDataOutBytes.Location = new System.Drawing.Point(20, 49);
            this.txtMILDataOutBytes.Name = "txtMILDataOutBytes";
            this.txtMILDataOutBytes.Size = new System.Drawing.Size(99, 24);
            this.txtMILDataOutBytes.TabIndex = 26;
            this.txtMILDataOutBytes.Text = "";
            // 
            // lblTXMILDataIN
            // 
            this.lblTXMILDataIN.AutoSize = true;
            this.lblTXMILDataIN.BackColor = System.Drawing.Color.MintCream;
            this.lblTXMILDataIN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTXMILDataIN.Location = new System.Drawing.Point(6, 79);
            this.lblTXMILDataIN.Name = "lblTXMILDataIN";
            this.lblTXMILDataIN.Size = new System.Drawing.Size(144, 19);
            this.lblTXMILDataIN.TabIndex = 22;
            this.lblTXMILDataIN.Text = "RX MIL Packet Received:";
            // 
            // lblTXMILDataOut
            // 
            this.lblTXMILDataOut.AutoSize = true;
            this.lblTXMILDataOut.BackColor = System.Drawing.Color.MintCream;
            this.lblTXMILDataOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTXMILDataOut.Location = new System.Drawing.Point(6, 27);
            this.lblTXMILDataOut.Name = "lblTXMILDataOut";
            this.lblTXMILDataOut.Size = new System.Drawing.Size(118, 19);
            this.lblTXMILDataOut.TabIndex = 20;
            this.lblTXMILDataOut.Text = "TX MIL Packet Sent:";
            // 
            // groupBox7
            // 
            this.groupBox7.AutoSize = true;
            this.groupBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox7.Controls.Add(this.txtLogMILRx);
            this.groupBox7.Controls.Add(this.txtLogMILTx);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox7.Location = new System.Drawing.Point(19, 297);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(791, 150);
            this.groupBox7.TabIndex = 24;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Log Window-Ethernet MIL Loopback";
            this.groupBox7.UseCompatibleTextRendering = true;
            // 
            // txtLogMILRx
            // 
            this.txtLogMILRx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogMILRx.Location = new System.Drawing.Point(6, 98);
            this.txtLogMILRx.Name = "txtLogMILRx";
            this.txtLogMILRx.Size = new System.Drawing.Size(778, 46);
            this.txtLogMILRx.TabIndex = 2;
            this.txtLogMILRx.Text = "";
            // 
            // txtLogMILTx
            // 
            this.txtLogMILTx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogMILTx.Location = new System.Drawing.Point(7, 34);
            this.txtLogMILTx.Name = "txtLogMILTx";
            this.txtLogMILTx.Size = new System.Drawing.Size(778, 49);
            this.txtLogMILTx.TabIndex = 1;
            this.txtLogMILTx.Text = "";
            // 
            // groupBox8
            // 
            this.groupBox8.AutoSize = true;
            this.groupBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox8.Controls.Add(this.txtethDataINBytes);
            this.groupBox8.Controls.Add(this.txtethDataOutBytes);
            this.groupBox8.Controls.Add(this.lblEthernetDataInLength);
            this.groupBox8.Controls.Add(this.lblEthernetDataOutLength);
            this.groupBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox8.Location = new System.Drawing.Point(817, 167);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(187, 142);
            this.groupBox8.TabIndex = 23;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "TX RX Ethernet Count";
            // 
            // txtethDataINBytes
            // 
            this.txtethDataINBytes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtethDataINBytes.Location = new System.Drawing.Point(18, 112);
            this.txtethDataINBytes.Name = "txtethDataINBytes";
            this.txtethDataINBytes.Size = new System.Drawing.Size(99, 24);
            this.txtethDataINBytes.TabIndex = 27;
            this.txtethDataINBytes.Text = "";
            // 
            // txtethDataOutBytes
            // 
            this.txtethDataOutBytes.Location = new System.Drawing.Point(18, 43);
            this.txtethDataOutBytes.Name = "txtethDataOutBytes";
            this.txtethDataOutBytes.Size = new System.Drawing.Size(99, 24);
            this.txtethDataOutBytes.TabIndex = 26;
            this.txtethDataOutBytes.Text = "";
            // 
            // lblEthernetDataInLength
            // 
            this.lblEthernetDataInLength.AutoSize = true;
            this.lblEthernetDataInLength.BackColor = System.Drawing.Color.MintCream;
            this.lblEthernetDataInLength.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEthernetDataInLength.Location = new System.Drawing.Point(6, 84);
            this.lblEthernetDataInLength.Name = "lblEthernetDataInLength";
            this.lblEthernetDataInLength.Size = new System.Drawing.Size(175, 19);
            this.lblEthernetDataInLength.TabIndex = 22;
            this.lblEthernetDataInLength.Text = "RX Ethernet  Packet Received:";
            // 
            // lblEthernetDataOutLength
            // 
            this.lblEthernetDataOutLength.AutoSize = true;
            this.lblEthernetDataOutLength.BackColor = System.Drawing.Color.MintCream;
            this.lblEthernetDataOutLength.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEthernetDataOutLength.Location = new System.Drawing.Point(7, 21);
            this.lblEthernetDataOutLength.Name = "lblEthernetDataOutLength";
            this.lblEthernetDataOutLength.Size = new System.Drawing.Size(145, 19);
            this.lblEthernetDataOutLength.TabIndex = 20;
            this.lblEthernetDataOutLength.Text = "TX Ethernet Packet Sent:";
            // 
            // gbLogWindowSerial
            // 
            this.gbLogWindowSerial.AutoSize = true;
            this.gbLogWindowSerial.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbLogWindowSerial.Controls.Add(this.txtLogEthLbk1Rx);
            this.gbLogWindowSerial.Controls.Add(this.txtLogEthLbk1Tx);
            this.gbLogWindowSerial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbLogWindowSerial.Location = new System.Drawing.Point(19, 19);
            this.gbLogWindowSerial.Name = "gbLogWindowSerial";
            this.gbLogWindowSerial.Size = new System.Drawing.Size(791, 143);
            this.gbLogWindowSerial.TabIndex = 3;
            this.gbLogWindowSerial.TabStop = false;
            this.gbLogWindowSerial.Text = "Log Window-Ethernet Loopback 1";
            this.gbLogWindowSerial.UseCompatibleTextRendering = true;
            // 
            // txtLogEthLbk1Rx
            // 
            this.txtLogEthLbk1Rx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogEthLbk1Rx.Location = new System.Drawing.Point(8, 85);
            this.txtLogEthLbk1Rx.Name = "txtLogEthLbk1Rx";
            this.txtLogEthLbk1Rx.Size = new System.Drawing.Size(777, 48);
            this.txtLogEthLbk1Rx.TabIndex = 1;
            this.txtLogEthLbk1Rx.Text = "";
            // 
            // txtLogEthLbk1Tx
            // 
            this.txtLogEthLbk1Tx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogEthLbk1Tx.Location = new System.Drawing.Point(8, 21);
            this.txtLogEthLbk1Tx.Name = "txtLogEthLbk1Tx";
            this.txtLogEthLbk1Tx.Size = new System.Drawing.Size(777, 58);
            this.txtLogEthLbk1Tx.TabIndex = 0;
            this.txtLogEthLbk1Tx.Text = "";
            // 
            // gbTXRXSerialCount
            // 
            this.gbTXRXSerialCount.AutoSize = true;
            this.gbTXRXSerialCount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbTXRXSerialCount.Controls.Add(this.txtSPDataInBytes);
            this.gbTXRXSerialCount.Controls.Add(this.txtSPDataOutBytes);
            this.gbTXRXSerialCount.Controls.Add(this.lblSPDataInLength);
            this.gbTXRXSerialCount.Controls.Add(this.lblSPDataOutLength);
            this.gbTXRXSerialCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbTXRXSerialCount.Location = new System.Drawing.Point(817, 24);
            this.gbTXRXSerialCount.Name = "gbTXRXSerialCount";
            this.gbTXRXSerialCount.Size = new System.Drawing.Size(187, 161);
            this.gbTXRXSerialCount.TabIndex = 20;
            this.gbTXRXSerialCount.TabStop = false;
            this.gbTXRXSerialCount.Text = "TX RX Serial Count";
            // 
            // txtSPDataInBytes
            // 
            this.txtSPDataInBytes.Location = new System.Drawing.Point(20, 111);
            this.txtSPDataInBytes.Name = "txtSPDataInBytes";
            this.txtSPDataInBytes.Size = new System.Drawing.Size(97, 26);
            this.txtSPDataInBytes.TabIndex = 25;
            this.txtSPDataInBytes.Text = "";
            // 
            // txtSPDataOutBytes
            // 
            this.txtSPDataOutBytes.Location = new System.Drawing.Point(20, 52);
            this.txtSPDataOutBytes.Name = "txtSPDataOutBytes";
            this.txtSPDataOutBytes.Size = new System.Drawing.Size(97, 22);
            this.txtSPDataOutBytes.TabIndex = 24;
            this.txtSPDataOutBytes.Text = "";
            // 
            // lblSPDataInLength
            // 
            this.lblSPDataInLength.AutoSize = true;
            this.lblSPDataInLength.BackColor = System.Drawing.Color.MintCream;
            this.lblSPDataInLength.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSPDataInLength.Location = new System.Drawing.Point(6, 89);
            this.lblSPDataInLength.Name = "lblSPDataInLength";
            this.lblSPDataInLength.Size = new System.Drawing.Size(137, 19);
            this.lblSPDataInLength.TabIndex = 22;
            this.lblSPDataInLength.Text = "RX SP Packet Received:";
            // 
            // lblSPDataOutLength
            // 
            this.lblSPDataOutLength.AutoSize = true;
            this.lblSPDataOutLength.BackColor = System.Drawing.Color.MintCream;
            this.lblSPDataOutLength.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSPDataOutLength.Location = new System.Drawing.Point(18, 21);
            this.lblSPDataOutLength.Name = "lblSPDataOutLength";
            this.lblSPDataOutLength.Size = new System.Drawing.Size(117, 19);
            this.lblSPDataOutLength.TabIndex = 20;
            this.lblSPDataOutLength.Text = "TX SP Packket Sent:";
            // 
            // groupBox9
            // 
            this.groupBox9.AutoSize = true;
            this.groupBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox9.Controls.Add(this.txtLogEthLbk2Rx);
            this.groupBox9.Controls.Add(this.txtLogEthLbk2Tx);
            this.groupBox9.Location = new System.Drawing.Point(19, 158);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(792, 151);
            this.groupBox9.TabIndex = 6;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Log Window-Ethernet Loopback 2";
            this.groupBox9.UseCompatibleTextRendering = true;
            // 
            // txtLogEthLbk2Rx
            // 
            this.txtLogEthLbk2Rx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogEthLbk2Rx.Location = new System.Drawing.Point(8, 79);
            this.txtLogEthLbk2Rx.Name = "txtLogEthLbk2Rx";
            this.txtLogEthLbk2Rx.Size = new System.Drawing.Size(778, 48);
            this.txtLogEthLbk2Rx.TabIndex = 2;
            this.txtLogEthLbk2Rx.Text = "";
            // 
            // txtLogEthLbk2Tx
            // 
            this.txtLogEthLbk2Tx.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogEthLbk2Tx.Location = new System.Drawing.Point(7, 24);
            this.txtLogEthLbk2Tx.Name = "txtLogEthLbk2Tx";
            this.txtLogEthLbk2Tx.Size = new System.Drawing.Size(778, 48);
            this.txtLogEthLbk2Tx.TabIndex = 1;
            this.txtLogEthLbk2Tx.Text = "";
            // 
            // gbSelectTest
            // 
            this.gbSelectTest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbSelectTest.Controls.Add(this.gbOptionsToSelect);
            this.gbSelectTest.Location = new System.Drawing.Point(6, 7);
            this.gbSelectTest.Name = "gbSelectTest";
            this.gbSelectTest.Size = new System.Drawing.Size(1158, 105);
            this.gbSelectTest.TabIndex = 5;
            this.gbSelectTest.TabStop = false;
            this.gbSelectTest.Text = "Options To Select ";
            // 
            // gbOptionsToSelect
            // 
            this.gbOptionsToSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbOptionsToSelect.Controls.Add(this.btnGenerateTestReport);
            this.gbOptionsToSelect.Controls.Add(this.btnClearTextBoxData);
            this.gbOptionsToSelect.Controls.Add(this.btnStopData);
            this.gbOptionsToSelect.Controls.Add(this.btnExitForm);
            this.gbOptionsToSelect.Controls.Add(this.btnStartToSendData);
            this.gbOptionsToSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbOptionsToSelect.Location = new System.Drawing.Point(6, 19);
            this.gbOptionsToSelect.Name = "gbOptionsToSelect";
            this.gbOptionsToSelect.Size = new System.Drawing.Size(1133, 62);
            this.gbOptionsToSelect.TabIndex = 1;
            this.gbOptionsToSelect.TabStop = false;
            // 
            // btnGenerateTestReport
            // 
            this.btnGenerateTestReport.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGenerateTestReport.BackColor = System.Drawing.Color.Snow;
            this.btnGenerateTestReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnGenerateTestReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGenerateTestReport.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerateTestReport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnGenerateTestReport.Location = new System.Drawing.Point(507, 24);
            this.btnGenerateTestReport.Name = "btnGenerateTestReport";
            this.btnGenerateTestReport.Size = new System.Drawing.Size(153, 32);
            this.btnGenerateTestReport.TabIndex = 27;
            this.btnGenerateTestReport.Text = "Generate Test Report";
            this.btnGenerateTestReport.UseVisualStyleBackColor = false;
            this.btnGenerateTestReport.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnGenerateTestReport_MouseDown);
            this.btnGenerateTestReport.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnGenerateTestReport_MouseUp);
            // 
            // btnClearTextBoxData
            // 
            this.btnClearTextBoxData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClearTextBoxData.BackColor = System.Drawing.Color.Snow;
            this.btnClearTextBoxData.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnClearTextBoxData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClearTextBoxData.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearTextBoxData.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnClearTextBoxData.Location = new System.Drawing.Point(754, 24);
            this.btnClearTextBoxData.Name = "btnClearTextBoxData";
            this.btnClearTextBoxData.Size = new System.Drawing.Size(54, 32);
            this.btnClearTextBoxData.TabIndex = 26;
            this.btnClearTextBoxData.Text = "Clear";
            this.btnClearTextBoxData.UseVisualStyleBackColor = false;
            this.btnClearTextBoxData.Click += new System.EventHandler(this.btnClearTextBoxData_Click);
            this.btnClearTextBoxData.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnClearTextBoxData_MouseDown);
            this.btnClearTextBoxData.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnClearTextBoxData_MouseUp);
            // 
            // btnStopData
            // 
            this.btnStopData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStopData.BackColor = System.Drawing.Color.Snow;
            this.btnStopData.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnStopData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStopData.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStopData.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnStopData.Location = new System.Drawing.Point(421, 24);
            this.btnStopData.Name = "btnStopData";
            this.btnStopData.Size = new System.Drawing.Size(68, 32);
            this.btnStopData.TabIndex = 5;
            this.btnStopData.Text = "Stop";
            this.btnStopData.UseVisualStyleBackColor = false;
            this.btnStopData.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnStopData_MouseDown);
            this.btnStopData.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnStopData_MouseUp);
            // 
            // btnExitForm
            // 
            this.btnExitForm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExitForm.BackColor = System.Drawing.Color.Snow;
            this.btnExitForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExitForm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExitForm.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExitForm.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnExitForm.Location = new System.Drawing.Point(678, 24);
            this.btnExitForm.Name = "btnExitForm";
            this.btnExitForm.Size = new System.Drawing.Size(58, 32);
            this.btnExitForm.TabIndex = 22;
            this.btnExitForm.Text = "Exit";
            this.btnExitForm.UseVisualStyleBackColor = false;
            this.btnExitForm.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnExitForm_MouseDown);
            this.btnExitForm.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnExitForm_MouseUp);
            // 
            // btnStartToSendData
            // 
            this.btnStartToSendData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStartToSendData.BackColor = System.Drawing.Color.Snow;
            this.btnStartToSendData.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnStartToSendData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStartToSendData.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartToSendData.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnStartToSendData.Location = new System.Drawing.Point(334, 24);
            this.btnStartToSendData.Name = "btnStartToSendData";
            this.btnStartToSendData.Size = new System.Drawing.Size(69, 32);
            this.btnStartToSendData.TabIndex = 4;
            this.btnStartToSendData.Text = "Start";
            this.btnStartToSendData.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnStartToSendData.UseVisualStyleBackColor = false;
            this.btnStartToSendData.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnStartToSendData_MouseDown);
            this.btnStartToSendData.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnStartToSendData_MouseUp);
            // 
            // panelHeader
            // 
            this.panelHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelHeader.AutoScroll = true;
            this.panelHeader.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panelHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panelHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelHeader.Location = new System.Drawing.Point(2, 66);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(1215, 12);
            this.panelHeader.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Location = new System.Drawing.Point(2, 673);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1228, 19);
            this.panel1.TabIndex = 7;
            // 
            // panelLeft
            // 
            this.panelLeft.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panelLeft.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.panelLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelLeft.Location = new System.Drawing.Point(2, 82);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(10, 585);
            this.panelLeft.TabIndex = 8;
            // 
            // panelRight
            // 
            this.panelRight.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelRight.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.panelRight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelRight.Location = new System.Drawing.Point(1198, 82);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(11, 587);
            this.panelRight.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // CIB
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1212, 693);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panelRight);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelHeader);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panelDateTimeDay);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "CIB";
            this.Text = "CIB MK-II Test UI";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelDateTimeDay.ResumeLayout(false);
            this.panelDateTimeDay.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.gbGeneralSetting.ResumeLayout(false);
            this.gbGeneralSetting.PerformLayout();
            this.gbTestSelection.ResumeLayout(false);
            this.gbTestSelection.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.gbEM1MilSettings.ResumeLayout(false);
            this.gbEM1MilSettings.PerformLayout();
            this.gbEthernetMil1Setting.ResumeLayout(false);
            this.gbEthernetMil1Setting.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.gbEthernetCommuncationSettingel2.ResumeLayout(false);
            this.gbEthernetCommuncationSettingel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.gbTestSettingsETM.ResumeLayout(false);
            this.gbTestSettingsETM.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.gbTXRXMILCount.ResumeLayout(false);
            this.gbTXRXMILCount.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.gbLogWindowSerial.ResumeLayout(false);
            this.gbTXRXSerialCount.ResumeLayout(false);
            this.gbTXRXSerialCount.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.gbSelectTest.ResumeLayout(false);
            this.gbOptionsToSelect.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelDateTimeDay;
        private System.Windows.Forms.Label lblDay;
        private System.Windows.Forms.Label lblDateValue;
        private System.Windows.Forms.Label lblTimeValue;
        private System.Windows.Forms.Timer timerDateDayTime;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox gbGeneralSetting;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox txtTesterName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbTestSelection;
        private System.Windows.Forms.CheckBox checkBoxEthernetToMIL;
        private System.Windows.Forms.CheckBox checkBoxSerialToEthernet;
        private System.Windows.Forms.CheckBox checkBoxEthernetSerial;
        private System.Windows.Forms.CheckBox checkBoxMilToEthernet;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox gbEM1MilSettings;
        private System.Windows.Forms.ComboBox cbEM1SubRTAddr;
        private System.Windows.Forms.Label lbEM1SubRtAddr;
        private System.Windows.Forms.ComboBox cbEM1RtAddr;
        private System.Windows.Forms.ComboBox cbEM1SelChannel;
        private System.Windows.Forms.Label lbEM1RtAddr;
        private System.Windows.Forms.Label lbEM1SelChannel;
        private System.Windows.Forms.Label lbEM1DevNum;
        private System.Windows.Forms.ComboBox cbEM1DevNum;
        private System.Windows.Forms.GroupBox gbEthernetMil1Setting;
        private System.Windows.Forms.RichTextBox tbEM1PortNum;
        private System.Windows.Forms.RichTextBox tbEM1ApAddr;
        private System.Windows.Forms.Label lbEM1TransmitPort;
        private System.Windows.Forms.Label lbEM1IpAddr;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox txtrxelPortNo;
        private System.Windows.Forms.Label lblrxelPortNo;
        private System.Windows.Forms.RichTextBox txtelIPAddress;
        private System.Windows.Forms.Label lbltxelPortNo;
        private System.Windows.Forms.Label lblelIPAddress;
        private System.Windows.Forms.GroupBox gbEthernetCommuncationSettingel2;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.RichTextBox txtReceivePortno2el2;
        private System.Windows.Forms.Label lblReceivePortNo2el2;
        private System.Windows.Forms.RichTextBox txtel2IPAddress;
        private System.Windows.Forms.Label lblTransmitPortNo1el2;
        private System.Windows.Forms.Label lblIPAddressel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnUpdateComPorts;
        private System.Windows.Forms.Label lblComPort;
        private System.Windows.Forms.Label lblBaudRate;
        private System.Windows.Forms.Label lblDataBits;
        private System.Windows.Forms.ComboBox cBoxPARITYBITS;
        private System.Windows.Forms.ComboBox cBoxDATABITS;
        private System.Windows.Forms.ComboBox cBoxSTOPBITS;
        private System.Windows.Forms.ComboBox cBoxBAUDRATE;
        private System.Windows.Forms.Label lblPARITYBITS;
        private System.Windows.Forms.Label lblStopBits;
        private System.Windows.Forms.ComboBox cBoxCOMPORT;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox gbTestSettingsETM;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.Label lblSerialTestResult;
        private System.Windows.Forms.GroupBox gbTXRXMILCount;
        private System.Windows.Forms.RichTextBox txtethMILINBytes;
        private System.Windows.Forms.RichTextBox txtMILDataOutBytes;
        private System.Windows.Forms.Label lblTXMILDataIN;
        private System.Windows.Forms.Label lblTXMILDataOut;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RichTextBox txtLogMILRx;
        private System.Windows.Forms.RichTextBox txtLogMILTx;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RichTextBox txtethDataINBytes;
        private System.Windows.Forms.RichTextBox txtethDataOutBytes;
        private System.Windows.Forms.Label lblEthernetDataInLength;
        private System.Windows.Forms.Label lblEthernetDataOutLength;
        private System.Windows.Forms.GroupBox gbLogWindowSerial;
        private System.Windows.Forms.RichTextBox txtLogEthLbk1Rx;
        private System.Windows.Forms.RichTextBox txtLogEthLbk1Tx;
        private System.Windows.Forms.GroupBox gbTXRXSerialCount;
        private System.Windows.Forms.RichTextBox txtSPDataInBytes;
        private System.Windows.Forms.RichTextBox txtSPDataOutBytes;
        private System.Windows.Forms.Label lblSPDataInLength;
        private System.Windows.Forms.Label lblSPDataOutLength;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RichTextBox txtLogEthLbk2Rx;
        private System.Windows.Forms.RichTextBox txtLogEthLbk2Tx;
        private System.Windows.Forms.GroupBox gbSelectTest;
        private System.Windows.Forms.GroupBox gbOptionsToSelect;
        private System.Windows.Forms.Button btnGenerateTestReport;
        private System.Windows.Forms.Button btnClearTextBoxData;
        private System.Windows.Forms.Button btnStopData;
        private System.Windows.Forms.Button btnExitForm;
        private System.Windows.Forms.Button btnStartToSendData;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

