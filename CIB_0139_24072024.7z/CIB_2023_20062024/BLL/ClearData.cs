﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace BLL
{
   public class ClearData
    {
        //  public static void ClearTextBoxData(
        public void ClearTextBoxData(
        RichTextBox txtLogEthLbk1Tx,
        RichTextBox txtLogEthLbk1Rx,
        RichTextBox txtLogEthLbk2Tx,
        RichTextBox txtLogEthLbk2Rx,
        RichTextBox txtLogMILTx,
        RichTextBox txtLogMILRx)
        {
            txtLogEthLbk1Tx.Clear();
            txtLogEthLbk1Rx.Clear();
            txtLogEthLbk2Tx.Clear();
            txtLogEthLbk2Rx.Clear();
            txtLogMILTx.Clear();
            txtLogMILRx.Clear();
        }
    }
}
