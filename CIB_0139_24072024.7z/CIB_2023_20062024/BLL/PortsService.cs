﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class PortsService
    {
        public string[] GetAllSerialPorts()
        {
            return SerialPort.GetPortNames();
        }

    }
}
