﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FHL
{
    public class ManualFileCreation
    {
        #region File Creation 
        public void CreateFile()
        {
            string fileName; FileInfo fi;
            string fileNameAtStorage = "SendDataWithManualMode.txt";
            string createdFileLocatedAt = Environment.CurrentDirectory;
            string ManualModeFilePath = createdFileLocatedAt + "\\" + fileNameAtStorage;
            fileName = ManualModeFilePath;

            fi = new FileInfo(fileName);
            try
            {
                if (!fi.Exists)
                {
                    StreamWriter sw = fi.CreateText();// Create a new file    
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.ToString());
            }
        }
        #endregion

    }
}
