﻿using System;
using System.Windows.Forms;

namespace CIB
{
    public partial class CIBForm : Form
    {
        public CIBForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class1 cl=new Class1 ();
            cl.Display();
            cl.sum(56, 67);
            
        }

        private void CIBForm_Load(object sender, EventArgs e)
        {

        }
    }
}
